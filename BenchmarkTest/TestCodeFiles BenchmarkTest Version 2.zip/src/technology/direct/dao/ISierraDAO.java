package technology.direct.dao;

public interface ISierraDAO {
	public static String NAME = "ISierraDAO";
}