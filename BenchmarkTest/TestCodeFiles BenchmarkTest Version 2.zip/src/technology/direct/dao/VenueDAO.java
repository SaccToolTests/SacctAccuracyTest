package technology.direct.dao;

public class VenueDAO {

}