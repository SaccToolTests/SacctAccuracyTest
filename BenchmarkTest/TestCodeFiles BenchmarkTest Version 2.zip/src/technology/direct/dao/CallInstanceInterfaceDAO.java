package technology.direct.dao;

public interface CallInstanceInterfaceDAO {
	public void InterfaceMethod();
	
}
