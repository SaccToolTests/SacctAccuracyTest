package technology.direct.dao;

public class BadgesDAO {
	public static String[] getAllBadges() {
		return new String[] {"badge1", "badge2"};
	}
}