package technology.direct.dao;

public class HistoryDAO {

}
