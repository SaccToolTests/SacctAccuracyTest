package technology.direct.dao;

public interface IMapDAO {

}