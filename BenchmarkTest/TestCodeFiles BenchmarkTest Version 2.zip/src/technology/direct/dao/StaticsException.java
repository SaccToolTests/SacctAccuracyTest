package technology.direct.dao;

@SuppressWarnings("serial")
public class StaticsException extends Exception{
	/**
	 * 
	 */
	public StaticsException(String message){
		super(message);
	}
}