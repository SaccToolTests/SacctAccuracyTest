package technology.direct.dao;

public abstract class FriendsDAO {

}