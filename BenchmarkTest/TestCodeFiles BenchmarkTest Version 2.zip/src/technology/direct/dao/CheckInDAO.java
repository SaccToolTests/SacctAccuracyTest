package technology.direct.dao;

public class CheckInDAO {
	public static String currentLocation = "Nijenoord 1, Utrecht";
}