package technology.direct.dao;

public class UserDAO {
	public static final String name = "username";
	public final String message = "The social information";
	
	public UserDAO() {
 
	}
}