package technology.direct.dao;

public @interface SettingsAnnotation {
	public String author() default "Themaopdracht 7 tester";
}