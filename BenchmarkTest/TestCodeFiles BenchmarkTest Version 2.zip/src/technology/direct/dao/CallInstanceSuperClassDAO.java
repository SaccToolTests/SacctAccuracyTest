package technology.direct.dao;

public class CallInstanceSuperClassDAO {
	
	public CallInstanceSuperClassDAO(){};
	
	public String VariableOnSuperClass;
	
	public void MethodOnSuperClass() {
		
	}
}
