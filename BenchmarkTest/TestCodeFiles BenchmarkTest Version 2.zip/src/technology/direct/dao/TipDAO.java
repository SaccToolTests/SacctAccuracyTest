package technology.direct.dao;

public enum TipDAO {
	ONE,TWO,THREE,FOUR
}