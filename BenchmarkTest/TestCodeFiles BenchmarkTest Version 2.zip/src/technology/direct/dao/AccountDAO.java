package technology.direct.dao;

public class AccountDAO {

}