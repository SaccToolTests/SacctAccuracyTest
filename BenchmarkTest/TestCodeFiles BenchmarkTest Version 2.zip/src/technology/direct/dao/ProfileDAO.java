package technology.direct.dao;

public class ProfileDAO {
	public String name = "profile";
	
	public String getCampaignType() {
		return "commercial";
	}

}
