package domain.indirect.allowedfrom;


import domain.indirect.intermediate.IWhrrl;

public class InheritanceImplementsExtendsIndirect implements IWhrrl {

	public InheritanceImplementsExtendsIndirect(){
	}
}