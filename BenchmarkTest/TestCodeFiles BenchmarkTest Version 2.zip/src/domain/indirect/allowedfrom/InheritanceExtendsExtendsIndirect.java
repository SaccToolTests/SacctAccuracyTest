package domain.indirect.allowedfrom;

import domain.indirect.intermediate.MapsService;

public class InheritanceExtendsExtendsIndirect extends MapsService {

}