package domain.indirect.allowedfrom;

import domain.indirect.intermediate.Whrrl;

public class InheritanceExtendsImplementsIndirect extends Whrrl {

	public InheritanceExtendsImplementsIndirect(){
	}
}