package domain.indirect.indirectto;
//Functional requirement 3.2
//Test case 147: Class domain.foursquarealternative.brightkite.Account is not allowed to have a dependency with classes in package domain.foursquarealternative.yelp
//Result: FALSE

public interface IPreferences {

}
