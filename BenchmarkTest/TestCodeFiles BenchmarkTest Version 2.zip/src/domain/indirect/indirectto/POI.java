package domain.indirect.indirectto;

public abstract class POI {
	public String name;
	
	public POI(){
		
	}

	public String getName(){
		return name;
	}
	

}
