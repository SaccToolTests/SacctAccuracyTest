package domain.indirect.intermediate;

import domain.indirect.indirectto.IPreferences;

public class Whrrl implements IPreferences{

}
