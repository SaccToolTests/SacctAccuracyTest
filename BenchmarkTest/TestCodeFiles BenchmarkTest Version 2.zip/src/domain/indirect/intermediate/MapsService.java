package domain.indirect.intermediate;

import domain.indirect.indirectto.POI;

public class MapsService extends POI {

}