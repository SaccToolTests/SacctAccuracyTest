package domain.indirect.intermediate;

import domain.indirect.indirectto.IPreferences;

public interface IWhrrl extends IPreferences{

}

