package domain.indirect.violatingfrom;

import domain.indirect.intermediate.Whrrl;

public class InheritanceExtendsImplementsIndirect extends Whrrl {

	public InheritanceExtendsImplementsIndirect(){
	}
}