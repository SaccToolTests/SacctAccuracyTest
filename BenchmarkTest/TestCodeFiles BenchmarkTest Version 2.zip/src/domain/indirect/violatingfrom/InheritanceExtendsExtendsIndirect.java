package domain.indirect.violatingfrom;

import domain.indirect.intermediate.MapsService;

public class InheritanceExtendsExtendsIndirect extends MapsService {

}