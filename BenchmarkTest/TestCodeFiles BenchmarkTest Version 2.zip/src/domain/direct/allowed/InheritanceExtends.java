package domain.direct.allowed;

import technology.direct.dao.HistoryDAO;

public class InheritanceExtends extends HistoryDAO {

}
