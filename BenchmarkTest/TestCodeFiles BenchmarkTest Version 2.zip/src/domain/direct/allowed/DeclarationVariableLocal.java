package domain.direct.allowed;

import technology.direct.dao.ProfileDAO;

public class DeclarationVariableLocal {
	
		public String getProfileInformation(){
			@SuppressWarnings("unused")
			ProfileDAO pdao;
		return "";
	}
}