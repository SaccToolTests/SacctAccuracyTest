package domain.direct.allowed;

import technology.direct.dao.TipDAO;

public class AccessEnumeration {
	public AccessEnumeration(){
		System.out.println(TipDAO.ONE);
	}
}