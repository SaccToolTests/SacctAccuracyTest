package domain.direct.allowed;

import technology.direct.dao.AccountDAO;

@SuppressWarnings("unused")
public class ImportDependencyUnused {	

}