package domain.direct.allowed;

import technology.direct.dao.ProfileDAO;

public class DeclarationVariableInstance {
	
	@SuppressWarnings("unused")
	private ProfileDAO pdao;
	public String getProfileInformation(){
		return "";
	}
}