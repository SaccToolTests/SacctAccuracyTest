package domain.direct.allowed;

import technology.direct.dao.ProfileDAO;

public class DeclarationVariableStatic {
	
	@SuppressWarnings("unused")
	private static ProfileDAO pdao;
	public String getProfileInformation(){
		return "";
	}
}