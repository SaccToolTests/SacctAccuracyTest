package domain.direct.allowed;

import technology.direct.dao.AccountDAO;

public class CallConstructor {
	public CallConstructor(){

		new AccountDAO();
	}
}