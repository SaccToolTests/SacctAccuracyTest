package domain.direct.allowed;

import technology.direct.dao.SettingsAnnotation;

@SettingsAnnotation
public class AnnotationDependency {

}