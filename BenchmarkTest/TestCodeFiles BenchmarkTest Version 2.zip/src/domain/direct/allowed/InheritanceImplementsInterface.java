package domain.direct.allowed;

import technology.direct.dao.IMapDAO;

public class InheritanceImplementsInterface implements IMapDAO {

}
