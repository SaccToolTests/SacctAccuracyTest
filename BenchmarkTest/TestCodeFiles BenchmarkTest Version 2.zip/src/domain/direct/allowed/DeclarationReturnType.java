package domain.direct.allowed;

import technology.direct.dao.VenueDAO;
public class DeclarationReturnType {
	public VenueDAO getVenues(){
		return null;
	}
}