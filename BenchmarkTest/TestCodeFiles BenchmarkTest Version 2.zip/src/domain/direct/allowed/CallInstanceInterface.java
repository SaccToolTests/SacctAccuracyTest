package domain.direct.allowed;

import domain.direct.Base;

public class CallInstanceInterface extends Base{

	public CallInstanceInterface(){};
	
	public void test() {
		interfaceDao.InterfaceMethod();
	}
	
}


