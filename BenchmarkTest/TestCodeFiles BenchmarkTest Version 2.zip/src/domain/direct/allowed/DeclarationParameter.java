package domain.direct.allowed;

import technology.direct.dao.ProfileDAO;

public class DeclarationParameter {
	
	public String getProfileInformation(ProfileDAO dao){
		return "";
	}
}