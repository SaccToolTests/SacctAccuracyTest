package domain.direct.allowed;

import technology.direct.dao.FriendsDAO;

public class InheritanceExtendsAbstractClass extends FriendsDAO {

}