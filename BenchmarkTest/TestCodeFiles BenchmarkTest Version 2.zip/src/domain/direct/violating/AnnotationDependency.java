package domain.direct.violating;

import technology.direct.dao.SettingsAnnotation;

@SettingsAnnotation
public class AnnotationDependency {

}