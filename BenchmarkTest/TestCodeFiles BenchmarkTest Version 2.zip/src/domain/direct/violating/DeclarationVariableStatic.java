package domain.direct.violating;

import technology.direct.dao.ProfileDAO;

public class DeclarationVariableStatic {
	
	@SuppressWarnings("unused")
	private static ProfileDAO pdao;
	public String getProfileInformation(){
		return "";
	}
}