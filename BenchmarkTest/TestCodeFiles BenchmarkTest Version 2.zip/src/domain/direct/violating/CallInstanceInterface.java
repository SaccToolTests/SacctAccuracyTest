package domain.direct.violating;

import domain.direct.Base;

public class CallInstanceInterface extends Base{

	public CallInstanceInterface(){};
	
	public void test() {
		interfaceDao.InterfaceMethod();
	}
	
}


