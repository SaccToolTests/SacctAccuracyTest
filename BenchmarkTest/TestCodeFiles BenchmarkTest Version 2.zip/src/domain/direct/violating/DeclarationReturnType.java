package domain.direct.violating;

import technology.direct.dao.VenueDAO;
public class DeclarationReturnType {
	public VenueDAO getVenues(){
		return null;
	}
}