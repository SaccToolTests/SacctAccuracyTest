package domain.direct.violating;

import technology.direct.dao.IMapDAO;

public class InheritanceImplementsInterface implements IMapDAO {

}
