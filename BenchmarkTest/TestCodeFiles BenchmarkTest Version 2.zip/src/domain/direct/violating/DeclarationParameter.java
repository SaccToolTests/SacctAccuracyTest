package domain.direct.violating;

import technology.direct.dao.ProfileDAO;

public class DeclarationParameter {
	
	public String getProfileInformation(ProfileDAO dao){
		return "";
	}
}