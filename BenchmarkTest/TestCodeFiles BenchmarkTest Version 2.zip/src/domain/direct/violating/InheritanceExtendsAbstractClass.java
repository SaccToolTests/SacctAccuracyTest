package domain.direct.violating;

import technology.direct.dao.FriendsDAO;

public class InheritanceExtendsAbstractClass extends FriendsDAO {

}