package domain.direct.violating;

import technology.direct.dao.HistoryDAO;

public class InheritanceExtends extends HistoryDAO {

}
