package domain.direct.violating;

import technology.direct.dao.TipDAO;

public class AccessEnumeration {
	public AccessEnumeration(){
		System.out.println(TipDAO.ONE);
	}
}