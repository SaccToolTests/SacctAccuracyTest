package domain.direct.violating;

import technology.direct.dao.AccountDAO;

@SuppressWarnings("unused")
public class ImportDependencyUnused {	

}